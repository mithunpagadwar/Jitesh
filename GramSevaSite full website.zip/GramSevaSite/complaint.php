<?php
session_start();

// Create data directory if it doesn't exist
if (!file_exists('data')) {
    mkdir('data', 0777, true);
}

// Create uploads directory if it doesn't exist
if (!file_exists('uploads/complaints')) {
    mkdir('uploads/complaints', 0777, true);
}

$success = false;
$error = '';
$complaint_id = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $mobile = $_POST['mobile'] ?? '';
    $complaint = $_POST['complaint'] ?? '';
    $complaint_id = time() . rand(1000, 9999);
    
    // Handle file upload
    $upload_dir = "uploads/complaints/";
    $file_path = '';
    if (isset($_FILES['document']) && $_FILES['document']['error'] == 0) {
        $allowed_types = array('jpg', 'jpeg', 'png', 'pdf', 'doc', 'docx');
        $file_extension = strtolower(pathinfo($_FILES['document']['name'], PATHINFO_EXTENSION));
        
        if (in_array($file_extension, $allowed_types)) {
            $file_path = $upload_dir . $complaint_id . '_' . basename($_FILES['document']['name']);
            if (move_uploaded_file($_FILES['document']['tmp_name'], $file_path)) {
                // File uploaded successfully
            } else {
                $error = "फाइल अपलोड करने में समस्या हुई।";
            }
        } else {
            $error = "केवल JPG, JPEG, PNG, PDF, DOC, DOCX फाइल्स ही अपलोड कर सकते हैं।";
        }
    }
    
    if (empty($error)) {
        // Save complaint to file
        $complaint_data = [
            'id' => $complaint_id,
            'name' => $name,
            'mobile' => $mobile,
            'complaint' => $complaint,
            'file' => $file_path,
            'status' => 'pending',
            'date' => date('Y-m-d H:i:s')
        ];
        
        $complaints = [];
        if (file_exists('data/complaints.json')) {
            $complaints = json_decode(file_get_contents('data/complaints.json'), true) ?: [];
        }
        $complaints[] = $complaint_data;
        file_put_contents('data/complaints.json', json_encode($complaints));
        
        // Send email
        $to = "gpchikhali66@gmail.com";
        $subject = "नई शिकायत - " . $complaint_id;
        $message = "नई शिकायत प्राप्त हुई है:\n\n";
        $message .= "शिकायत क्रमांक: " . $complaint_id . "\n";
        $message .= "नाम: " . $name . "\n";
        $message .= "मोबाइल: " . $mobile . "\n";
        $message .= "शिकायत: " . $complaint . "\n";
        
        $headers = "From: webmaster@grampanchayatchikhali.com";
        
        mail($to, $subject, $message, $headers);
        
        $success = true;
    }
}
?>
<!DOCTYPE html>
<html lang="hi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>शिकायत दर्ज करें - ग्राम पंचायत चिखली</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include 'header.php'; ?>
    
    <div class="container py-4">
        <div class="row">
            <div class="col-lg-8 mx-auto">
                <?php if ($success): ?>
                    <div class="alert alert-success">
                        <h4>आपकी शिकायत सफलतापूर्वक दर्ज कर ली गई है</h4>
                        <p>आपका शिकायत क्रमांक है: <strong><?php echo htmlspecialchars($complaint_id); ?></strong></p>
                        <p>कृपया इस क्रमांक को संभाल कर रखें। इससे आप अपनी शिकायत का स्टेटस जान सकते हैं।</p>
                        <div class="mt-4">
                            <a href="check-complaint.php" class="btn btn-info text-white">शिकायत का स्टेटस जांचें</a>
                            <a href="index.php" class="btn btn-outline-primary ms-2">होम पेज पर जाएं</a>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="card complaint-form">
                        <div class="card-body">
                            <h2 class="card-title text-center mb-4">शिकायत दर्ज करें</h2>
                            
                            <?php if (!empty($error)): ?>
                                <div class="alert alert-danger"><?php echo $error; ?></div>
                            <?php endif; ?>
                            
                            <form method="POST" enctype="multipart/form-data">
                                <div class="mb-3">
                                    <label for="name" class="form-label">पूरा नाम</label>
                                    <input type="text" class="form-control" id="name" name="name" required>
                                </div>
                                <div class="mb-3">
                                    <label for="mobile" class="form-label">मोबाइल नंबर</label>
                                    <input type="tel" class="form-control" id="mobile" name="mobile" pattern="[0-9]{10}" required>
                                    <small class="form-text text-muted">10 अंकों का मोबाइल नंबर दर्ज करें</small>
                                </div>
                                <div class="mb-3">
                                    <label for="complaint" class="form-label">शिकायत विवरण</label>
                                    <textarea class="form-control" id="complaint" name="complaint" rows="5" required></textarea>
                                </div>
                                <div class="mb-3">
                                    <label for="document" class="form-label">दस्तावेज अपलोड करें (वैकल्पिक)</label>
                                    <input type="file" class="form-control" id="document" name="document">
                                    <small class="form-text text-muted">अनुमत फाइल प्रकार: JPG, JPEG, PNG, PDF, DOC, DOCX</small>
                                </div>
                                <button type="submit" class="btn btn-primary w-100">शिकायत दर्ज करें</button>
                            </form>
                        </div>
                    </div>
                    
                    <div class="card mt-4">
                        <div class="card-body">
                            <h4 class="card-title">शिकायत का स्टेटस जांचें</h4>
                            <p>यदि आपने पहले शिकायत दर्ज की है, तो आप अपने शिकायत क्रमांक से स्टेटस जांच सकते हैं।</p>
                            <a href="check-complaint.php" class="btn btn-outline-primary">शिकायत स्टेटस जांचें</a>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <?php include 'footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
