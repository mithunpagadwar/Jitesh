<?php
session_start();
?>
<!DOCTYPE html>
<html lang="hi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ग्राम पंचायत चिखली</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css" />
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include 'header.php'; ?>

    <div class="swiper my-4">
        <div class="swiper-wrapper">
            <div class="swiper-slide">
                <img src="data:image/svg+xml;base64,<?php echo base64_encode('<svg xmlns="http://www.w3.org/2000/svg" width="800" height="400" viewBox="0 0 800 400"><rect width="800" height="400" fill="#f8bb14"/><text x="400" y="200" font-family="Arial" font-size="30" text-anchor="middle" fill="#000">ग्राम पंचायत चिखली</text></svg>'); ?>" alt="ग्राम पंचायत चिखली">
            </div>
            <div class="swiper-slide">
                <img src="data:image/svg+xml;base64,<?php echo base64_encode('<svg xmlns="http://www.w3.org/2000/svg" width="800" height="400" viewBox="0 0 800 400"><rect width="800" height="400" fill="#138808"/><text x="400" y="200" font-family="Arial" font-size="30" text-anchor="middle" fill="#fff">स्वच्छ गाँव - सुंदर गाँव</text></svg>'); ?>" alt="स्वच्छ गाँव - सुंदर गाँव">
            </div>
            <div class="swiper-slide">
                <img src="data:image/svg+xml;base64,<?php echo base64_encode('<svg xmlns="http://www.w3.org/2000/svg" width="800" height="400" viewBox="0 0 800 400"><rect width="800" height="400" fill="#FF9933"/><text x="400" y="200" font-family="Arial" font-size="30" text-anchor="middle" fill="#fff">डिजिटल इंडिया - डिजिटल गाँव</text></svg>'); ?>" alt="डिजिटल इंडिया">
            </div>
        </div>
        <div class="swiper-pagination"></div>
        <div class="swiper-button-prev"></div>
        <div class="swiper-button-next"></div>
    </div>

    <main class="container my-4">
        <section class="welcome-section text-center mb-5">
            <h2>ग्राम पंचायत चिखली में आपका स्वागत है</h2>
            <p>हम अपने ग्रामवासियों को बेहतर सेवाएं प्रदान करने के लिए प्रतिबद्ध हैं।</p>
        </section>

        <section class="services-grid">
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="card text-center h-100">
                        <div class="card-body">
                            <i class="fas fa-home fa-3x mb-3 text-primary"></i>
                            <h3>घर टैक्स</h3>
                            <p>ऑनलाइन घर टैक्स जमा करें</p>
                            <a href="housetax.php" class="btn btn-primary">अधिक जानें</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card text-center h-100">
                        <div class="card-body">
                            <i class="fas fa-tint fa-3x mb-3 text-primary"></i>
                            <h3>पानी बिल</h3>
                            <p>पानी का बिल ऑनलाइन जमा करें</p>
                            <a href="housetax.php" class="btn btn-primary">अधिक जानें</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card text-center h-100">
                        <div class="card-body">
                            <i class="fas fa-comments fa-3x mb-3 text-primary"></i>
                            <h3>शिकायत</h3>
                            <p>अपनी शिकायत दर्ज करें</p>
                            <a href="complaint.php" class="btn btn-primary">शिकायत दर्ज करें</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="schemes-section mt-5">
            <h2 class="text-center mb-4">प्रमुख सरकारी योजनाएं</h2>
            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <div class="card-body text-center">
                            <i class="fas fa-landmark fa-3x mb-3 text-warning"></i>
                            <h4>प्रधानमंत्री आवास योजना</h4>
                            <p>सभी के लिए घर सुनिश्चित करने वाली योजना</p>
                            <a href="schemes.php#pmay" class="btn btn-outline-primary">अधिक जानकारी</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <div class="card-body text-center">
                            <i class="fas fa-hand-holding-medical fa-3x mb-3 text-danger"></i>
                            <h4>आयुष्मान भारत</h4>
                            <p>स्वास्थ्य बीमा और सेवाएं प्रदान करने की योजना</p>
                            <a href="schemes.php#ayushman" class="btn btn-outline-primary">अधिक जानकारी</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <div class="card-body text-center">
                            <i class="fas fa-tractor fa-3x mb-3 text-success"></i>
                            <h4>पीएम किसान</h4>
                            <p>किसानों के लिए आर्थिक सहायता योजना</p>
                            <a href="schemes.php#pmkisan" class="btn btn-outline-primary">अधिक जानकारी</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="text-center mt-3">
                <a href="schemes.php" class="btn btn-primary">सभी योजनाएं देखें</a>
            </div>
        </section>

        <section class="gallery-preview mt-5">
            <h2 class="text-center mb-4">गैलरी झलक</h2>
            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <img src="data:image/svg+xml;base64,<?php echo base64_encode('<svg xmlns="http://www.w3.org/2000/svg" width="400" height="300" viewBox="0 0 400 300"><rect width="400" height="300" fill="#f0f0f0"/><text x="200" y="150" font-family="Arial" font-size="18" text-anchor="middle" fill="#555">ग्रामसभा फोटो</text></svg>'); ?>" class="card-img-top" alt="ग्रामसभा फोटो">
                        <div class="card-body text-center">
                            <h5 class="card-title">ग्रामसभा</h5>
                            <a href="gallery.php#gram-sabha" class="btn btn-sm btn-outline-primary">और देखें</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <img src="data:image/svg+xml;base64,<?php echo base64_encode('<svg xmlns="http://www.w3.org/2000/svg" width="400" height="300" viewBox="0 0 400 300"><rect width="400" height="300" fill="#f0f0f0"/><text x="200" y="150" font-family="Arial" font-size="18" text-anchor="middle" fill="#555">मासिक सभा फोटो</text></svg>'); ?>" class="card-img-top" alt="मासिक सभा फोटो">
                        <div class="card-body text-center">
                            <h5 class="card-title">मासिक सभा</h5>
                            <a href="gallery.php#monthly-meeting" class="btn btn-sm btn-outline-primary">और देखें</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <img src="data:image/svg+xml;base64,<?php echo base64_encode('<svg xmlns="http://www.w3.org/2000/svg" width="400" height="300" viewBox="0 0 400 300"><rect width="400" height="300" fill="#f0f0f0"/><text x="200" y="150" font-family="Arial" font-size="18" text-anchor="middle" fill="#555">सांस्कृतिक कार्यक्रम फोटो</text></svg>'); ?>" class="card-img-top" alt="सांस्कृतिक कार्यक्रम फोटो">
                        <div class="card-body text-center">
                            <h5 class="card-title">सांस्कृतिक कार्यक्रम</h5>
                            <a href="gallery.php#cultural" class="btn btn-sm btn-outline-primary">और देखें</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="text-center mt-3">
                <a href="gallery.php" class="btn btn-primary">पूरी गैलरी देखें</a>
            </div>
        </section>
    </main>

    <?php include 'footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
