<?php
session_start();

// Initialize UPI ID
$upi_id = file_exists('data/upi_id.txt') ? file_get_contents('data/upi_id.txt') : 'gpchikhali66@ybl';

// Handle login logic
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $loginId = $_POST['loginId'] ?? '';
    if(!empty($loginId)) {
        if(is_numeric($loginId) && (strlen($loginId) == 10 || strlen($loginId) <= 4)) {
            $_SESSION['resident_logged_in'] = true;
            $_SESSION['login_id'] = $loginId;
            header("Location: housetax.php");
            exit;
        } else {
            $error = 'कृपया सही क्रमांक या मोबाइल नंबर डालें';
        }
    }
}

// Handle logout
if(isset($_GET['logout'])) {
    session_unset();
    session_destroy();
    header("Location: housetax.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="hi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>घर टैक्स/पानी टैक्स भुगतान - ग्राम पंचायत चिखली</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include 'header.php'; ?>

    <div class="container py-4">
        <div class="row">
            <div class="col-lg-10 mx-auto">
                <h1 class="text-center mb-4">घर टैक्स/पानी टैक्स भुगतान</h1>

                <?php if(!isset($_SESSION['resident_logged_in'])): ?>
                    <div class="login-container">
                        <h2 class="text-center mb-4">लॉगिन करें</h2>
                        <p class="text-center mb-4">अपना क्रमांक या मोबाइल नंबर दर्ज करके टैक्स जमा करें</p>
                        <form method="POST" action="" class="needs-validation" novalidate>
                            <div class="mb-3">
                                <label for="loginId" class="form-label">आपका क्रमांक या मोबाइल नंबर</label>
                                <input type="text" class="form-control" id="loginId" name="loginId" 
                                       placeholder="उदाहरण: 9876543210 या 1234" required>
                                <div class="invalid-feedback">
                                    कृपया सही क्रमांक या मोबाइल नंबर डालें
                                </div>
                            </div>
                            <?php if(isset($error)): ?>
                                <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
                            <?php endif; ?>
                            <button type="submit" class="btn btn-primary w-100">लॉगिन करें</button>
                        </form>
                    </div>
                <?php else: ?>
                    <div class="text-end mb-4">
                        <a href="?logout=1" class="btn btn-outline-danger">
                            <i class="fas fa-sign-out-alt"></i> लॉगआउट
                        </a>
                    </div>

                    <div id="searchForm" class="search-box mb-4">
                        <div class="mb-3">
                            <label for="searchInput" class="form-label">नाम या क्रमांक से खोजें</label>
                            <input type="text" class="form-control" id="searchInput" 
                                   placeholder="नाम या क्रमांक दर्ज करें...">
                        </div>
                    </div>

                    <div id="searchResults" class="residents-container"></div>
                    
                    <!-- Payment Modal -->
                    <div class="modal fade" id="paymentModal" tabindex="-1" aria-labelledby="paymentModalLabel" aria-hidden="false">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="paymentModalLabel">भुगतान विवरण</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body" id="paymentDetails">
                                    <!-- Payment details will be inserted here -->
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <?php include 'footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Generate residents data
        const residents = [];
        for(let i = 1; i <= 1000; i++) {
            const ward = Math.floor(Math.random() * 10) + 1;
            const house = Math.floor(Math.random() * 999) + 1;
            const mobile = '98765' + String(i).padStart(5, '0');
            residents.push({
                id: i,
                name: `निवासी ${i}`,
                address: `वार्ड ${ward}, मकान ${house}`,
                mobile: mobile,
                houseTax: 500,
                waterTax: 300
            });
        }

        // UPI ID from PHP
        const upiId = "<?php echo $upi_id; ?>";
        
        if(document.getElementById('searchInput')) {
            document.getElementById('searchInput').addEventListener('input', searchResidents);
            searchResidents(); // Show all residents initially
        }

        function searchResidents() {
            const searchInput = document.getElementById('searchInput');
            const searchResults = document.getElementById('searchResults');
            const searchTerm = searchInput ? searchInput.value.toLowerCase().trim() : '';

            let results = residents;
            if(searchTerm) {
                results = residents.filter(resident => 
                    resident.name.toLowerCase().includes(searchTerm) || 
                    resident.id.toString().includes(searchTerm) ||
                    resident.mobile.includes(searchTerm)
                );
            }
            
            // Limit to first 20 results to avoid overwhelming the page
            const displayResults = results.slice(0, 20);

            searchResults.innerHTML = displayResults.map(resident => `
                <div class="resident-card">
                    <div class="resident-info">
                        <div class="resident-photo-container">
                            <img src="data:image/svg+xml;base64,${generateAvatarSvg(resident.id)}" alt="${resident.name}" class="resident-photo">
                        </div>
                        <div class="resident-details">
                            <h4>${resident.name}</h4>
                            <p><strong>क्रमांक:</strong> ${resident.id}</p>
                            <p><strong>पता:</strong> ${resident.address}</p>
                            <p><strong>मोबाइल:</strong> ${resident.mobile}</p>
                        </div>
                    </div>
                    <div class="payment-buttons">
                        <button onclick="showPayment(${resident.id}, 'house')" class="btn btn-primary">
                            घर टैक्स भरें (₹${resident.houseTax})
                        </button>
                        <button onclick="showPayment(${resident.id}, 'water')" class="btn btn-info text-white">
                            पानी टैक्स भरें (₹${resident.waterTax})
                        </button>
                    </div>
                </div>
            `).join('');
            
            if (results.length > 20) {
                searchResults.innerHTML += `
                    <div class="alert alert-info mt-3">
                        <i class="fas fa-info-circle"></i> ${results.length - 20} और परिणाम हैं। कृपया अधिक विशिष्ट खोज शब्द का उपयोग करें।
                    </div>
                `;
            }
            
            if (results.length === 0) {
                searchResults.innerHTML = `
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle"></i> कोई परिणाम नहीं मिला। कृपया अलग खोज शब्द का उपयोग करें।
                    </div>
                `;
            }
        }

        function showPayment(residentId, type) {
            const resident = residents.find(r => r.id === residentId);
            if (!resident) return;

            const amount = type === 'house' ? resident.houseTax : resident.waterTax;
            const typeText = type === 'house' ? 'घर टैक्स' : 'पानी टैक्स';
            
            const paymentDetails = document.getElementById('paymentDetails');
            paymentDetails.innerHTML = `
                <div class="text-center mb-4">
                    <img src="data:image/svg+xml;base64,${generateAvatarSvg(resident.id)}" alt="${resident.name}" class="resident-photo mb-2">
                    <h4>${resident.name}</h4>
                </div>
                <div class="payment-info">
                    <p><strong>क्रमांक:</strong> ${resident.id}</p>
                    <p><strong>मोबाइल:</strong> ${resident.mobile}</p>
                    <p><strong>भुगतान प्रकार:</strong> ${typeText}</p>
                    <p><strong>राशि:</strong> ₹${amount}</p>
                </div>
                <hr>
                <div class="upi-payment text-center">
                    <p>UPI के माध्यम से भुगतान करें</p>
                    <div class="upi-qr">
                        <img src="data:image/svg+xml;base64,${generateQRCodeSvg(upiId, amount, resident.id, typeText)}" alt="UPI QR Code" style="max-width: 200px;">
                    </div>
                    <p class="mt-2">UPI ID: ${upiId}</p>
                    <button onclick="processPayment(${residentId}, '${type}')" class="btn btn-success mt-3">
                        <i class="fas fa-money-bill-wave"></i> भुगतान करें
                    </button>
                </div>
            `;
            
            const paymentModal = new bootstrap.Modal(document.getElementById('paymentModal'));
            paymentModal.show();
        }

        function processPayment(residentId, type) {
            const resident = residents.find(r => r.id === residentId);
            if (!resident) return;
            
            const amount = type === 'house' ? resident.houseTax : resident.waterTax;
            const typeText = type === 'house' ? 'घर टैक्स' : 'पानी टैक्स';
            
            // In a real system, this would redirect to a payment gateway
            // For demo purposes, we'll just show a success message
            document.getElementById('paymentDetails').innerHTML = `
                <div class="text-center">
                    <i class="fas fa-check-circle text-success" style="font-size: 4rem;"></i>
                    <h4 class="mt-3">भुगतान सफल</h4>
                    <p>आपने सफलतापूर्वक ₹${amount} का ${typeText} जमा किया है।</p>
                    <p><strong>रसीद संख्या:</strong> ${new Date().getTime()}</p>
                    <p><strong>दिनांक:</strong> ${new Date().toLocaleDateString()}</p>
                    <button onclick="window.print()" class="btn btn-outline-primary mt-3">
                        <i class="fas fa-print"></i> रसीद प्रिंट करें
                    </button>
                </div>
            `;
        }

        function generateAvatarSvg(id) {
            // Simple SVG avatar generator
            const colors = ['#4CAF50', '#2196F3', '#9C27B0', '#F44336', '#FF9800'];
            const color = colors[id % colors.length];
            
            const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 100 100">
                <circle cx="50" cy="50" r="48" fill="${color}" />
                <text x="50" y="55" font-family="Arial" font-size="30" text-anchor="middle" fill="white">${id}</text>
            </svg>`;
            
            return btoa(svg);
        }

        function generateQRCodeSvg(upiId, amount, residentId, typeText) {
            // Simple SVG QR code placeholder
            const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" viewBox="0 0 200 200">
                <rect width="200" height="200" fill="white" stroke="black" stroke-width="2"/>
                <text x="100" y="80" font-family="Arial" font-size="14" text-anchor="middle">UPI QR Code</text>
                <text x="100" y="100" font-family="Arial" font-size="12" text-anchor="middle">${upiId}</text>
                <text x="100" y="120" font-family="Arial" font-size="12" text-anchor="middle">₹${amount}</text>
                <text x="100" y="140" font-family="Arial" font-size="10" text-anchor="middle">निवासी: ${residentId}</text>
            </svg>`;
            
            return btoa(svg);
        }
    </script>
    <script src="js/main.js"></script>
</body>
</html>
