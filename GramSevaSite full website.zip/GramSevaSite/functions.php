<?php
// Utility functions for the Gram Panchayat website

/**
 * Get the current UPI ID from the data file
 */
function get_upi_id() {
    if (file_exists('data/upi_id.txt')) {
        return file_get_contents('data/upi_id.txt');
    }
    return 'gpchikhali66@ybl'; // Default UPI ID
}

/**
 * Save complaint data
 */
function save_complaint($name, $mobile, $complaint, $file_path = '') {
    $complaint_id = time() . rand(1000, 9999);
    
    $complaint_data = [
        'id' => $complaint_id,
        'name' => $name,
        'mobile' => $mobile,
        'complaint' => $complaint,
        'file' => $file_path,
        'status' => 'pending',
        'date' => date('Y-m-d H:i:s')
    ];
    
    $complaints = [];
    if (file_exists('data/complaints.json')) {
        $complaints = json_decode(file_get_contents('data/complaints.json'), true) ?: [];
    }
    $complaints[] = $complaint_data;
    file_put_contents('data/complaints.json', json_encode($complaints));
    
    return $complaint_id;
}

/**
 * Get complaint by ID
 */
function get_complaint_by_id($complaint_id) {
    if (file_exists('data/complaints.json')) {
        $complaints = json_decode(file_get_contents('data/complaints.json'), true) ?: [];
        foreach ($complaints as $complaint) {
            if ($complaint['id'] == $complaint_id) {
                return $complaint;
            }
        }
    }
    return null;
}

/**
 * Update complaint status
 */
function update_complaint_status($complaint_id, $status) {
    if (file_exists('data/complaints.json')) {
        $complaints = json_decode(file_get_contents('data/complaints.json'), true) ?: [];
        foreach ($complaints as &$complaint) {
            if ($complaint['id'] == $complaint_id) {
                $complaint['status'] = $status;
                file_put_contents('data/complaints.json', json_encode($complaints));
                return true;
            }
        }
    }
    return false;
}

/**
 * Generate a simple avatar SVG based on an ID
 */
function generate_avatar_svg($id) {
    $colors = ['#4CAF50', '#2196F3', '#9C27B0', '#F44336', '#FF9800'];
    $color = $colors[$id % count($colors)];
    
    $svg = '<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 100 100">';
    $svg .= '<circle cx="50" cy="50" r="48" fill="' . $color . '" />';
    $svg .= '<text x="50" y="55" font-family="Arial" font-size="30" text-anchor="middle" fill="white">' . $id . '</text>';
    $svg .= '</svg>';
    
    return base64_encode($svg);
}

/**
 * Generate a simple QR code SVG placeholder
 */
function generate_qr_code_svg($upi_id, $amount, $purpose) {
    $svg = '<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" viewBox="0 0 200 200">';
    $svg .= '<rect width="200" height="200" fill="white" stroke="black" stroke-width="2"/>';
    $svg .= '<text x="100" y="80" font-family="Arial" font-size="14" text-anchor="middle">UPI QR Code</text>';
    $svg .= '<text x="100" y="100" font-family="Arial" font-size="12" text-anchor="middle">' . $upi_id . '</text>';
    $svg .= '<text x="100" y="120" font-family="Arial" font-size="12" text-anchor="middle">₹' . $amount . '</text>';
    $svg .= '<text x="100" y="140" font-family="Arial" font-size="10" text-anchor="middle">' . $purpose . '</text>';
    $svg .= '</svg>';
    
    return base64_encode($svg);
}

/**
 * Send notification email about complaint
 */
function send_complaint_email($complaint_id, $name, $mobile, $complaint) {
    $to = "gpchikhali66@gmail.com";
    $subject = "नई शिकायत - " . $complaint_id;
    $message = "नई शिकायत प्राप्त हुई है:\n\n";
    $message .= "शिकायत क्रमांक: " . $complaint_id . "\n";
    $message .= "नाम: " . $name . "\n";
    $message .= "मोबाइल: " . $mobile . "\n";
    $message .= "शिकायत: " . $complaint . "\n";
    
    $headers = "From: webmaster@grampanchayatchikhali.com";
    
    return mail($to, $subject, $message, $headers);
}

/**
 * Sanitize user input
 */
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>
