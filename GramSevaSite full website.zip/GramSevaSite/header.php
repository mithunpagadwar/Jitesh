<?php 
if(!isset($_SESSION)) {
    session_start();
}
?>
<header class="header">
    <div class="container d-flex align-items-center justify-content-between">
        <img src="data:image/svg+xml;base64,<?php echo base64_encode('<svg xmlns="http://www.w3.org/2000/svg" width="80" height="80" viewBox="0 0 80 80"><circle cx="40" cy="40" r="38" fill="#fff" stroke="#000" stroke-width="2"/><text x="40" y="45" font-family="Arial" font-size="14" text-anchor="middle" fill="#000">चिखली</text></svg>'); ?>" alt="ग्राम पंचायत लोगो" height="80">
        <div class="text-center">
            <h1 class="mb-0">ग्राम पंचायत चिखली</h1>
            <p class="mb-0">जिला गडचिरोली, महाराष्ट्र</p>
        </div>
        <img src="data:image/svg+xml;base64,<?php echo base64_encode('<svg xmlns="http://www.w3.org/2000/svg" width="80" height="80" viewBox="0 0 80 80"><circle cx="40" cy="40" r="38" fill="#fff" stroke="#000" stroke-width="2"/><text x="40" y="35" font-family="Arial" font-size="14" text-anchor="middle" fill="#000">G20</text><text x="40" y="50" font-family="Arial" font-size="10" text-anchor="middle" fill="#000">INDIA</text></svg>'); ?>" alt="G20 लोगो" height="80">
    </div>
</header>

<nav class="nav">
    <div class="container">
        <ul class="nav-menu" id="main-menu">
            <li><a href="index.php" <?php echo (basename($_SERVER['PHP_SELF']) == 'index.php') ? 'class="active"' : ''; ?>>होम</a></li>
            <li><a href="schemes.php" <?php echo (basename($_SERVER['PHP_SELF']) == 'schemes.php') ? 'class="active"' : ''; ?>>योजनाएं</a></li>
            <li><a href="gallery.php" <?php echo (basename($_SERVER['PHP_SELF']) == 'gallery.php') ? 'class="active"' : ''; ?>>फोटो गैलरी</a></li>
            <li><a href="housetax.php" <?php echo (basename($_SERVER['PHP_SELF']) == 'housetax.php') ? 'class="active"' : ''; ?>>घरटैक्स/पाणी टैक्स</a></li>
            <li><a href="complaint.php" <?php echo (basename($_SERVER['PHP_SELF']) == 'complaint.php') ? 'class="active"' : ''; ?>>शिकायत</a></li>
            <li><a href="admin/login.php" <?php echo (basename($_SERVER['PHP_SELF']) == 'login.php' && dirname($_SERVER['PHP_SELF']) == '/admin') ? 'class="active"' : ''; ?>>प्रशासकीय लॉगिन</a></li>
        </ul>
        <button class="mobile-menu-toggle d-md-none">
            <i class="fas fa-bars"></i>
        </button>
    </div>
</nav>
