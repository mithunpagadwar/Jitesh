<?php session_start(); ?>
<!DOCTYPE html>
<html lang="hi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>सरकारी योजनाएं - ग्राम पंचायत चिखली</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include 'header.php'; ?>

    <main class="container my-4">
        <h1 class="text-center mb-4">सरकारी योजनाएं</h1>
        <p class="text-center mb-5">यहां आप भारत सरकार और महाराष्ट्र सरकार की प्रमुख योजनाओं के बारे में जानकारी प्राप्त कर सकते हैं</p>

        <div class="row" id="pmkisan">
            <div class="col-md-4 mb-4">
                <div class="scheme-card">
                    <img src="data:image/svg+xml;base64,<?php echo base64_encode('<svg xmlns="http://www.w3.org/2000/svg" width="400" height="200" viewBox="0 0 400 200"><rect width="400" height="200" fill="#138808"/><text x="200" y="100" font-family="Arial" font-size="24" text-anchor="middle" fill="#fff">प्रधानमंत्री किसान सम्मान निधि</text></svg>'); ?>" alt="PM किसान योजना" class="scheme-image w-100">
                    <div class="scheme-content">
                        <h3 class="scheme-title">प्रधानमंत्री किसान सम्मान निधि</h3>
                        <p class="scheme-description">किसानों को प्रति वर्ष ₹6,000 की वित्तीय सहायता प्रदान की जाती है, जो प्रति चार महीने में ₹2,000 की तीन किस्तों में दी जाती है।</p>
                        <div class="d-flex justify-content-between align-items-center">
                            <a href="https://pmkisan.gov.in/" target="_blank" class="scheme-link">
                                <i class="fas fa-external-link-alt"></i> अधिक जानकारी
                            </a>
                            <span class="badge bg-success">सक्रिय</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4 mb-4" id="pmay">
                <div class="scheme-card">
                    <img src="data:image/svg+xml;base64,<?php echo base64_encode('<svg xmlns="http://www.w3.org/2000/svg" width="400" height="200" viewBox="0 0 400 200"><rect width="400" height="200" fill="#FF9933"/><text x="200" y="100" font-family="Arial" font-size="24" text-anchor="middle" fill="#fff">प्रधानमंत्री आवास योजना</text></svg>'); ?>" alt="PM आवास योजना" class="scheme-image w-100">
                    <div class="scheme-content">
                        <h3 class="scheme-title">प्रधानमंत्री आवास योजना</h3>
                        <p class="scheme-description">2022 तक सभी नागरिकों को पक्का घर उपलब्ध कराने के उद्देश्य से आवास आवंटन और निर्माण के लिए वित्तीय सहायता प्रदान की जाती है।</p>
                        <div class="d-flex justify-content-between align-items-center">
                            <a href="https://pmaymis.gov.in/" target="_blank" class="scheme-link">
                                <i class="fas fa-external-link-alt"></i> अधिक जानकारी
                            </a>
                            <span class="badge bg-success">सक्रिय</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4 mb-4">
                <div class="scheme-card">
                    <img src="data:image/svg+xml;base64,<?php echo base64_encode('<svg xmlns="http://www.w3.org/2000/svg" width="400" height="200" viewBox="0 0 400 200"><rect width="400" height="200" fill="#4682B4"/><text x="200" y="100" font-family="Arial" font-size="24" text-anchor="middle" fill="#fff">मनरेगा</text></svg>'); ?>" alt="मनरेगा" class="scheme-image w-100">
                    <div class="scheme-content">
                        <h3 class="scheme-title">मनरेगा</h3>
                        <p class="scheme-description">ग्रामीण परिवारों के वयस्क सदस्यों को प्रति वित्तीय वर्ष में कम से कम 100 दिनों के रोजगार की गारंटी प्रदान करता है।</p>
                        <div class="d-flex justify-content-between align-items-center">
                            <a href="https://nrega.nic.in/" target="_blank" class="scheme-link">
                                <i class="fas fa-external-link-alt"></i> अधिक जानकारी
                            </a>
                            <span class="badge bg-success">सक्रिय</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4 mb-4" id="ayushman">
                <div class="scheme-card">
                    <img src="data:image/svg+xml;base64,<?php echo base64_encode('<svg xmlns="http://www.w3.org/2000/svg" width="400" height="200" viewBox="0 0 400 200"><rect width="400" height="200" fill="#E52B50"/><text x="200" y="100" font-family="Arial" font-size="24" text-anchor="middle" fill="#fff">आयुष्मान भारत</text></svg>'); ?>" alt="आयुष्मान भारत" class="scheme-image w-100">
                    <div class="scheme-content">
                        <h3 class="scheme-title">आयुष्मान भारत</h3>
                        <p class="scheme-description">गरीब और वंचित परिवारों को द्वितीयक और तृतीयक अस्पताल में भर्ती होने पर प्रति परिवार प्रति वर्ष 5 लाख रुपये तक का स्वास्थ्य बीमा कवर प्रदान करता है।</p>
                        <div class="d-flex justify-content-between align-items-center">
                            <a href="https://pmjay.gov.in/" target="_blank" class="scheme-link">
                                <i class="fas fa-external-link-alt"></i> अधिक जानकारी
                            </a>
                            <span class="badge bg-success">सक्रिय</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4 mb-4">
                <div class="scheme-card">
                    <img src="data:image/svg+xml;base64,<?php echo base64_encode('<svg xmlns="http://www.w3.org/2000/svg" width="400" height="200" viewBox="0 0 400 200"><rect width="400" height="200" fill="#6B8E23"/><text x="200" y="100" font-family="Arial" font-size="24" text-anchor="middle" fill="#fff">प्रधानमंत्री उज्ज्वला योजना</text></svg>'); ?>" alt="उज्ज्वला योजना" class="scheme-image w-100">
                    <div class="scheme-content">
                        <h3 class="scheme-title">प्रधानमंत्री उज्ज्वला योजना</h3>
                        <p class="scheme-description">गरीब परिवारों की महिलाओं को मुफ्त एलपीजी कनेक्शन प्रदान करना, जिससे उन्हें खाना पकाने के लिए स्वच्छ ईंधन मिल सके।</p>
                        <div class="d-flex justify-content-between align-items-center">
                            <a href="https://pmuy.gov.in/" target="_blank" class="scheme-link">
                                <i class="fas fa-external-link-alt"></i> अधिक जानकारी
                            </a>
                            <span class="badge bg-success">सक्रिय</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4 mb-4">
                <div class="scheme-card">
                    <img src="data:image/svg+xml;base64,<?php echo base64_encode('<svg xmlns="http://www.w3.org/2000/svg" width="400" height="200" viewBox="0 0 400 200"><rect width="400" height="200" fill="#9370DB"/><text x="200" y="100" font-family="Arial" font-size="24" text-anchor="middle" fill="#fff">जन धन योजना</text></svg>'); ?>" alt="जन धन योजना" class="scheme-image w-100">
                    <div class="scheme-content">
                        <h3 class="scheme-title">प्रधानमंत्री जन धन योजना</h3>
                        <p class="scheme-description">वित्तीय समावेशन की राष्ट्रीय मिशन जो प्रत्येक परिवार को बैंकिंग सेवाओं का उपयोग करने के लिए प्रोत्साहित करता है।</p>
                        <div class="d-flex justify-content-between align-items-center">
                            <a href="https://pmjdy.gov.in/" target="_blank" class="scheme-link">
                                <i class="fas fa-external-link-alt"></i> अधिक जानकारी
                            </a>
                            <span class="badge bg-success">सक्रिय</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4 mb-4">
                <div class="scheme-card">
                    <img src="data:image/svg+xml;base64,<?php echo base64_encode('<svg xmlns="http://www.w3.org/2000/svg" width="400" height="200" viewBox="0 0 400 200"><rect width="400" height="200" fill="#20B2AA"/><text x="200" y="100" font-family="Arial" font-size="24" text-anchor="middle" fill="#fff">स्वच्छ भारत मिशन</text></svg>'); ?>" alt="स्वच्छ भारत मिशन" class="scheme-image w-100">
                    <div class="scheme-content">
                        <h3 class="scheme-title">स्वच्छ भारत मिशन</h3>
                        <p class="scheme-description">खुले में शौच को समाप्त करने और ठोस अपशिष्ट प्रबंधन को बेहतर बनाने के उद्देश्य से स्वच्छता की स्थिति में सुधार लाना।</p>
                        <div class="d-flex justify-content-between align-items-center">
                            <a href="https://swachhbharat.mygov.in/" target="_blank" class="scheme-link">
                                <i class="fas fa-external-link-alt"></i> अधिक जानकारी
                            </a>
                            <span class="badge bg-success">सक्रिय</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4 mb-4">
                <div class="scheme-card">
                    <img src="data:image/svg+xml;base64,<?php echo base64_encode('<svg xmlns="http://www.w3.org/2000/svg" width="400" height="200" viewBox="0 0 400 200"><rect width="400" height="200" fill="#FF7F50"/><text x="200" y="100" font-family="Arial" font-size="24" text-anchor="middle" fill="#fff">पीएम मुद्रा योजना</text></svg>'); ?>" alt="मुद्रा योजना" class="scheme-image w-100">
                    <div class="scheme-content">
                        <h3 class="scheme-title">पीएम मुद्रा योजना</h3>
                        <p class="scheme-description">लघु व्यवसायों को वित्तीय सहायता प्रदान करना जिससे उनका विकास हो सके और रोजगार के अवसर बढ़ें।</p>
                        <div class="d-flex justify-content-between align-items-center">
                            <a href="https://www.mudra.org.in/" target="_blank" class="scheme-link">
                                <i class="fas fa-external-link-alt"></i> अधिक जानकारी
                            </a>
                            <span class="badge bg-success">सक्रिय</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4 mb-4">
                <div class="scheme-card">
                    <img src="data:image/svg+xml;base64,<?php echo base64_encode('<svg xmlns="http://www.w3.org/2000/svg" width="400" height="200" viewBox="0 0 400 200"><rect width="400" height="200" fill="#1E90FF"/><text x="200" y="100" font-family="Arial" font-size="24" text-anchor="middle" fill="#fff">अटल पेंशन योजना</text></svg>'); ?>" alt="अटल पेंशन योजना" class="scheme-image w-100">
                    <div class="scheme-content">
                        <h3 class="scheme-title">अटल पेंशन योजना</h3>
                        <p class="scheme-description">असंगठित क्षेत्र के नागरिकों के लिए सामाजिक सुरक्षा प्रदान करती है, जिससे उन्हें 60 वर्ष की उम्र के बाद एक निश्चित न्यूनतम पेंशन मिल सके।</p>
                        <div class="d-flex justify-content-between align-items-center">
                            <a href="https://www.npscra.nsdl.co.in/scheme-details.php" target="_blank" class="scheme-link">
                                <i class="fas fa-external-link-alt"></i> अधिक जानकारी
                            </a>
                            <span class="badge bg-success">सक्रिय</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="text-center my-5">
            <h2>अन्य महत्वपूर्ण सरकारी वेबसाइट लिंक्स</h2>
            <div class="row mt-4">
                <div class="col-md-6">
                    <ul class="list-group">
                        <li class="list-group-item"><a href="https://www.maharashtra.gov.in" target="_blank" class="text-decoration-none">महाराष्ट्र सरकार</a></li>
                        <li class="list-group-item"><a href="https://www.india.gov.in" target="_blank" class="text-decoration-none">भारत सरकार</a></li>
                        <li class="list-group-item"><a href="https://www.mygov.in" target="_blank" class="text-decoration-none">माय गव</a></li>
                        <li class="list-group-item"><a href="https://www.digital-india.gov.in" target="_blank" class="text-decoration-none">डिजिटल इंडिया</a></li>
                        <li class="list-group-item"><a href="https://mahabhulekh.maharashtra.gov.in" target="_blank" class="text-decoration-none">महाभूलेख</a></li>
                    </ul>
                </div>
                <div class="col-md-6">
                    <ul class="list-group">
                        <li class="list-group-item"><a href="https://aaple.maharashtra.gov.in" target="_blank" class="text-decoration-none">आपले सरकार</a></li>
                        <li class="list-group-item"><a href="https://www.mahapwd.com" target="_blank" class="text-decoration-none">सार्वजनिक बांधकाम विभाग</a></li>
                        <li class="list-group-item"><a href="https://www.nvsp.in" target="_blank" class="text-decoration-none">मतदाता पोर्टल</a></li>
                        <li class="list-group-item"><a href="https://www.uidai.gov.in" target="_blank" class="text-decoration-none">आधार</a></li>
                        <li class="list-group-item"><a href="https://www.panchayat.gov.in" target="_blank" class="text-decoration-none">पंचायती राज</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </main>

    <?php include 'footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
