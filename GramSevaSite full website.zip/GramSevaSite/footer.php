<footer class="footer">
    <div class="container footer-content">
        <div class="footer-section">
            <h3>संपर्क करें</h3>
            <p><i class="fas fa-map-marker-alt"></i> ग्राम पंचायत कार्यालय, चिखली</p>
            <p><i class="fas fa-phone"></i> 07133-245678</p>
            <p><i class="fas fa-envelope"></i> gpchikhali66@gmail.com</p>
        </div>
        <div class="footer-section">
            <h3>महत्वपूर्ण लिंक्स</h3>
            <p><a href="schemes.php" class="text-white">सरकारी योजनाएं</a></p>
            <p><a href="gallery.php" class="text-white">फोटो गैलरी</a></p>
            <p><a href="complaint.php" class="text-white">शिकायत</a></p>
            <p><a href="housetax.php" class="text-white">घरटैक्स/पाणी टैक्स</a></p>
        </div>
        <div class="footer-section">
            <h3>नक्शे पर स्थान</h3>
            <div class="google-map">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3721.4858773124993!2d79.85646007424365!3d20.33175447958868!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bd278d4a555555%3A0x3b11c6f5c60ea4a2!2sGram%20Panchayat%20Office%20Chikhali!5e0!3m2!1sen!2sin!4v1689871234567!5m2!1sen!2sin" width="100%" height="200" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
        </div>
    </div>
    <div class="container copyright-section text-center mt-3 pt-3 border-top border-light">
        <p class="mb-0">&copy; <?php echo date('Y'); ?> ग्राम पंचायत चिखली. सर्वाधिकार सुरक्षित.</p>
    </div>
</footer>
